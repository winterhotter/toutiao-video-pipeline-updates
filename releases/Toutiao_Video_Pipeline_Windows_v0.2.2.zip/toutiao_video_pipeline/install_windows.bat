@echo off
title Toutiao Video Pipeline - Installer
cd /d "%~dp0"

where py >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [ERROR] Python was not found.
    echo Install Python 3.11 or newer from:
    echo https://www.python.org/downloads/windows/
    echo Select "Add Python to PATH" during installation.
    pause
    exit /b 1
  )
  set "PYTHON_CMD=python"
)

if not exist .venv (
  echo Creating the local Python environment...
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 goto :failed
)

echo Installing required components...
call .venv\Scripts\python.exe -m pip install --upgrade pip
call .venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :failed

where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo.
  echo FFmpeg was not found. Trying to install it with winget...
  where winget >nul 2>nul
  if errorlevel 1 (
    echo [NOTICE] Install FFmpeg manually and add it to PATH.
    echo Recommended command: winget install --id Gyan.FFmpeg -e
  ) else (
    winget install --id Gyan.FFmpeg -e --accept-package-agreements --accept-source-agreements
  )
)

echo.
echo Creating a desktop shortcut...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_desktop_shortcut.ps1"
if errorlevel 1 (
  echo [NOTICE] The desktop shortcut could not be created.
  echo You can still launch the app with start_windows.bat.
)

echo.
echo Installation completed successfully.
echo Use the "Toutiao Video Pipeline" desktop shortcut to launch the app.
echo You can also double-click start_windows.bat in this folder.
pause
exit /b 0

:failed
echo.
echo [ERROR] Installation did not complete.
echo Take a screenshot of this window and send it for troubleshooting.
pause
exit /b 1

