from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Callable

from .database import Database
from .models import JobStatus, VideoJob
from .text_ai import ChineseMetadata, build_metadata_prompt, generate_metadata
from .chatgpt_handoff import build_no_api_chatgpt_prompt
from .cover_designer import generate_cover_variants

ProgressCallback = Callable[[str], None]


def safe_filename(value: str, limit: int = 70) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip(" ._")
    value = re.sub(r"\s+", " ", value)
    return (value[:limit].rstrip() or "未命名视频")


def default_output_root() -> Path:
    home = Path.home()
    documents = home / "Documents"
    return (documents if documents.exists() else home) / "头条视频流水线"


def app_data_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home()))
        return base / "ToutiaoVideoPipeline"
    return Path.home() / ".local" / "share" / "toutiao-video-pipeline"


def build_cover_prompt(title: str, original_title: str, category_hint: str = "") -> str:
    return f"""请参考我上传的视频截图，为今日头条视频制作一张高点击率横版封面背景。

视频中文标题：{title}
原始标题：{original_title}
内容提示：{category_hint[:500]}

设计要求：
- 保留截图中真实出现的主体，不虚构视频里没有的内容。
- 主体近距离、清晰、明亮、有层次，增强质感但不要失真。
- 构图简洁，适合手机信息流浏览。
- 上方中间保留约40%的干净深色区域，方便软件添加中文标题。
- 不添加任何文字、字母、Logo、边框或水印。
- 横幅比例16:9，同时兼顾2.35:1裁剪安全区，画面边缘保留安全空间。
"""


class VideoProcessor:
    def __init__(self, db: Database, output_root: Path):
        self.db = db
        self.output_root = output_root
        self.output_root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def check_dependencies() -> list[str]:
        missing: list[str] = []
        try:
            import yt_dlp  # noqa: F401
        except ImportError:
            missing.append("yt-dlp")
        try:
            import PIL  # noqa: F401
        except ImportError:
            missing.append("Pillow")
        if shutil.which("ffmpeg") is None:
            missing.append("FFmpeg")
        return missing

    def _download(self, job: VideoJob, folder: Path, progress: ProgressCallback) -> dict:
        try:
            import yt_dlp
        except ImportError as exc:
            raise RuntimeError("缺少yt-dlp，请先运行安装脚本") from exc

        def hook(data: dict) -> None:
            if data.get("status") == "downloading":
                percent = str(data.get("_percent_str", "")).strip()
                speed = str(data.get("_speed_str", "")).strip()
                progress(f"视频 #{job.id} 下载 {percent} {speed}")

        template = str(folder / "source.%(ext)s")
        options = {
            "outtmpl": template,
            "format": "bv*+ba/b",
            "merge_output_format": "mp4",
            "noplaylist": True,
            "writeinfojson": True,
            "writethumbnail": True,
            "progress_hooks": [hook],
            "quiet": True,
            "no_warnings": True,
        }
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(job.source_url, download=True)

        candidates = [
            p for p in folder.glob("source.*")
            if p.suffix.lower() in {".mp4", ".mkv", ".webm", ".mov"}
        ]
        if not candidates:
            raise RuntimeError("下载完成后没有找到视频文件")
        source_video = max(candidates, key=lambda p: p.stat().st_size)
        video_path = folder / "video.mp4"
        if source_video.suffix.lower() == ".mp4":
            if source_video != video_path:
                if video_path.exists():
                    video_path.unlink()
                source_video.replace(video_path)
        else:
            if video_path.exists():
                video_path.unlink()
            progress(f"视频 #{job.id} 正在转换为MP4")
            command = [
                "ffmpeg", "-y", "-i", str(source_video),
                "-c:v", "libx264", "-preset", "medium", "-crf", "21",
                "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart",
                str(video_path),
            ]
            result = subprocess.run(command, capture_output=True, text=True)
            if result.returncode != 0:
                raise RuntimeError("视频无法转换为MP4，请检查FFmpeg安装")
            source_video.unlink(missing_ok=True)
        return info

    @staticmethod
    def _extract_reference(video_path: Path, output_path: Path, duration: float) -> None:
        seek = max(1.0, min(duration * 0.22, 30.0)) if duration else 3.0
        command = [
            "ffmpeg", "-y", "-ss", str(seek), "-i", str(video_path),
            "-frames:v", "1", "-q:v", "2", str(output_path),
        ]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError("无法从视频提取封面参考图，请确认FFmpeg已经安装")

    @staticmethod
    def _write_text_files(folder: Path, data: dict[str, str]) -> None:
        for filename, content in data.items():
            (folder / filename).write_text(content.strip() + "\n", encoding="utf-8")

    def process_job(
        self,
        job_id: int,
        *,
        api_key: str,
        model: str,
        progress: ProgressCallback,
    ) -> None:
        job = self.db.get_job(job_id)
        if not job:
            return
        temp_folder = self.output_root / f"V{job.id:04d}_处理中"
        temp_folder.mkdir(parents=True, exist_ok=True)
        active_folder = temp_folder
        try:
            self.db.update_job(job.id, status=JobStatus.DOWNLOADING.value, error_message="")
            progress(f"开始处理视频 #{job.id}")
            video_path = temp_folder / "video.mp4"
            info_path = temp_folder / "source.info.json"
            if video_path.exists() and info_path.exists():
                info = json.loads(info_path.read_text(encoding="utf-8"))
                progress(f"视频 #{job.id} 已下载，继续处理")
            else:
                info = self._download(job, temp_folder, progress)

            original_title = str(info.get("title") or "未命名视频")
            author = str(info.get("channel") or info.get("uploader") or "")
            source_license = str(info.get("license") or "未在视频信息中发现许可证标记")
            original_description = str(info.get("description") or "")
            duration = float(info.get("duration") or 0)

            reference_path = temp_folder / "封面参考图.jpg"
            if not reference_path.exists():
                self._extract_reference(video_path, reference_path, duration)

            self.db.update_job(job.id, status=JobStatus.GENERATING.value)
            progress(f"视频 #{job.id} 正在生成中文标题和简介")
            metadata = generate_metadata(
                api_key=api_key,
                model=model,
                original_title=original_title,
                author=author,
                description=original_description,
            )
            cover_prompt = build_cover_prompt(
                metadata.primary_title, original_title, original_description
            )
            final_folder = self.output_root / (
                f"V{job.id:04d}_{safe_filename(metadata.primary_title)}"
            )
            if final_folder != temp_folder:
                if final_folder.exists():
                    shutil.rmtree(final_folder)
                temp_folder.rename(final_folder)
            active_folder = final_folder

            alternatives = "\n".join(
                [f"主标题：{metadata.primary_title}"]
                + [f"备选{i + 1}：{title}" for i, title in enumerate(metadata.alternative_titles)]
            )
            tags_text = " ".join(f"#{tag}" for tag in metadata.tags)
            source_text = (
                f"原作者/频道：{author}\n"
                f"平台许可证信息：{source_license}\n"
                f"授权状态：{job.rights_note}"
            )
            self._write_text_files(
                final_folder,
                {
                    "标题.txt": alternatives,
                    "简介.txt": f"{metadata.description}\n\n{tags_text}".strip(),
                    "授权记录.txt": source_text,
                    "ChatGPT封面提示词.txt": cover_prompt,
                    "ChatGPT标题提示词_备用.txt": build_metadata_prompt(
                        original_title, author, original_description
                    ),
                    "ChatGPT一键生成标题和封面.txt": build_no_api_chatgpt_prompt(
                        original_title, author, original_description
                    ),
                },
            )
            self.db.update_job(
                job.id,
                status=JobStatus.READY_FOR_COVER.value,
                original_title=original_title,
                chinese_title=metadata.primary_title,
                alternative_titles="\n".join(metadata.alternative_titles),
                description=metadata.description,
                tags=",".join(metadata.tags),
                source_author=author,
                source_license=source_license,
                output_dir=str(final_folder),
                cover_prompt=cover_prompt,
                error_message="",
            )
            progress(f"视频 #{job.id} 已准备好，请使用ChatGPT生成封面")
        except Exception as exc:
            self.db.update_job(
                job.id, status=JobStatus.ERROR.value, error_message=str(exc),
                output_dir=str(active_folder),
            )
            progress(f"视频 #{job.id} 失败：{exc}")

    def get_no_api_prompt(self, job_id: int) -> str:
        job = self.db.get_job(job_id)
        if not job or not job.folder:
            raise ValueError("请先处理视频，再使用ChatGPT")
        info_path = job.folder / "source.info.json"
        info: dict = {}
        if info_path.exists():
            info = json.loads(info_path.read_text(encoding="utf-8"))
        prompt = build_no_api_chatgpt_prompt(
            str(info.get("title") or job.original_title),
            str(info.get("channel") or info.get("uploader") or job.source_author),
            str(info.get("description") or ""),
        )
        (job.folder / "ChatGPT一键生成标题和封面.txt").write_text(
            prompt + "\n", encoding="utf-8"
        )
        return prompt

    def apply_metadata(self, job_id: int, metadata: ChineseMetadata) -> None:
        job = self.db.get_job(job_id)
        if not job or not job.folder:
            raise ValueError("请先处理视频，再粘贴ChatGPT结果")
        prompt = build_cover_prompt(
            metadata.primary_title, job.original_title, metadata.description
        )
        title_lines = [f"主标题：{metadata.primary_title}"] + [
            f"备选{i + 1}：{title}" for i, title in enumerate(metadata.alternative_titles)
        ]
        tags_text = " ".join(f"#{tag}" for tag in metadata.tags)
        self._write_text_files(
            job.folder,
            {
                "标题.txt": "\n".join(title_lines),
                "简介.txt": f"{metadata.description}\n\n{tags_text}".strip(),
                "ChatGPT封面提示词.txt": prompt,
            },
        )
        cover_exists = (job.folder / "cover.jpg").exists()
        self.db.update_job(
            job_id,
            chinese_title=metadata.primary_title,
            alternative_titles="\n".join(metadata.alternative_titles),
            description=metadata.description,
            tags=",".join(metadata.tags),
            cover_prompt=prompt,
            status=(
                JobStatus.READY_TO_PUBLISH.value
                if cover_exists else JobStatus.READY_FOR_COVER.value
            ),
            error_message="",
        )

    def import_cover(self, job_id: int, source: Path) -> Path:
        job = self.db.get_job(job_id)
        if not job or not job.folder:
            raise ValueError("请先处理视频，再导入封面")
        if not re.search(r"[\u4e00-\u9fff]", job.chinese_title):
            raise ValueError("当前主标题还不是中文，请先粘贴ChatGPT生成的中文结果")
        tags = [tag.strip() for tag in job.tags.split(",") if tag.strip()]
        outputs = generate_cover_variants(
            source, job.folder, job.chinese_title, tags=tags
        )
        self.db.update_job(job_id, status=JobStatus.READY_TO_PUBLISH.value)
        return outputs[0]

    @staticmethod
    def _find_chinese_font(ImageFont):
        candidates = [
            Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "msyhbd.ttc",
            Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "msyh.ttc",
            Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "simhei.ttf",
            Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"),
            Path("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"),
        ]
        for path in candidates:
            if path.exists():
                return path
        return None

    @classmethod
    def _add_title_overlay(cls, image, title: str, ImageDraw, ImageFont):
        title = title.strip()
        if not title:
            return image
        font_path = cls._find_chinese_font(ImageFont)
        if font_path is None:
            raise RuntimeError("没有找到中文字体。Windows系统请确认微软雅黑字体可用。")

        overlay = image.convert("RGBA")
        draw = ImageDraw.Draw(overlay, "RGBA")
        max_width = 390
        chosen_font = None
        lines: list[str] = []
        for size in range(58, 35, -2):
            font = ImageFont.truetype(str(font_path), size=size)
            current = ""
            wrapped: list[str] = []
            for char in title:
                candidate = current + char
                width = draw.textbbox((0, 0), candidate, font=font, stroke_width=2)[2]
                if width <= max_width or not current:
                    current = candidate
                else:
                    wrapped.append(current)
                    current = char
            if current:
                wrapped.append(current)
            if len(wrapped) <= 3:
                chosen_font, lines = font, wrapped
                break
        if chosen_font is None:
            chosen_font = ImageFont.truetype(str(font_path), size=34)
            lines = [title[:12], title[12:24], title[24:30]]

        spacing = 10
        boxes = [draw.textbbox((0, 0), line, font=chosen_font, stroke_width=2) for line in lines]
        text_width = max(box[2] - box[0] for box in boxes)
        line_height = max(box[3] - box[1] for box in boxes)
        text_height = line_height * len(lines) + spacing * (len(lines) - 1)
        x = 34
        y = max(26, (image.height - text_height) // 2)
        pad_x, pad_y = 20, 18
        draw.rounded_rectangle(
            (x - pad_x, y - pad_y, x + text_width + pad_x, y + text_height + pad_y),
            radius=20,
            fill=(0, 0, 0, 138),
        )
        cursor_y = y
        for line in lines:
            draw.text(
                (x, cursor_y),
                line,
                font=chosen_font,
                fill=(255, 255, 255, 255),
                stroke_width=2,
                stroke_fill=(0, 0, 0, 220),
            )
            cursor_y += line_height + spacing
        return overlay.convert("RGB")
