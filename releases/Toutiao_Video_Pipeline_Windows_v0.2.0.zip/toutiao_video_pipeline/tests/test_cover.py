from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from toutiao_pipeline.database import Database
from toutiao_pipeline.models import JobStatus
from toutiao_pipeline.processor import VideoProcessor

try:
    from PIL import Image
except ImportError:
    Image = None


@unittest.skipIf(Image is None, "Pillow is not installed")
class CoverTests(unittest.TestCase):
    def test_import_cover_outputs_exact_toutiao_size(self) -> None:
        font_candidates = [
            Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"),
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        ]
        font = next((path for path in font_candidates if path.exists()), None)
        if font is None:
            self.skipTest("No test font is installed")

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            db = Database(root / "workflow.db")
            job, _ = db.add_job("https://example.com/video", "本人原创")
            folder = root / "output" / "V0001"
            folder.mkdir(parents=True)
            db.update_job(
                job.id,
                status=JobStatus.READY_FOR_COVER.value,
                chinese_title="巧克力麻薯挑战",
                output_dir=str(folder),
            )
            source = root / "source.png"
            Image.new("RGB", (1536, 656), (205, 120, 80)).save(source)

            with patch.object(VideoProcessor, "_find_chinese_font", return_value=font):
                result = VideoProcessor(db, root / "output").import_cover(job.id, source)
            with Image.open(result) as cover:
                self.assertEqual(cover.size, (900, 383))
                self.assertEqual(cover.mode, "RGB")
            self.assertEqual(db.get_job(job.id).status, JobStatus.READY_TO_PUBLISH.value)


if __name__ == "__main__":
    unittest.main()

