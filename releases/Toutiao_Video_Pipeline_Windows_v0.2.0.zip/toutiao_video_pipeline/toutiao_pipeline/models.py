from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path


class JobStatus(StrEnum):
    QUEUED = "等待处理"
    DOWNLOADING = "正在下载"
    GENERATING = "正在生成标题"
    READY_FOR_COVER = "等待ChatGPT封面"
    READY_TO_PUBLISH = "可以发布"
    PUBLISHED = "已发布"
    ERROR = "处理失败"


@dataclass(slots=True)
class VideoJob:
    id: int
    source_url: str
    rights_note: str
    status: str
    original_title: str = ""
    chinese_title: str = ""
    alternative_titles: str = ""
    description: str = ""
    tags: str = ""
    source_author: str = ""
    source_license: str = ""
    output_dir: str = ""
    cover_prompt: str = ""
    error_message: str = ""
    created_at: str = ""
    updated_at: str = ""

    @property
    def folder(self) -> Path | None:
        return Path(self.output_dir) if self.output_dir else None

