from __future__ import annotations

import hashlib
import json
import re
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import urlparse

from . import __version__


MANIFEST_URL = (
    "https://raw.githubusercontent.com/winterhotter/"
    "toutiao-video-pipeline-updates/main/version.json"
)
ALLOWED_DOWNLOAD_HOSTS = {
    "github.com",
    "raw.githubusercontent.com",
    "objects.githubusercontent.com",
}


@dataclass(slots=True)
class UpdateInfo:
    version: str
    package_url: str
    sha256: str
    release_notes: list[str]
    published_at: str = ""


def version_tuple(value: str) -> tuple[int, ...]:
    numbers = [int(part) for part in re.findall(r"\d+", value)]
    return tuple(numbers or [0])


def is_newer_version(candidate: str, current: str = __version__) -> bool:
    left = version_tuple(candidate)
    right = version_tuple(current)
    length = max(len(left), len(right))
    return left + (0,) * (length - len(left)) > right + (0,) * (length - len(right))


def _open_request(url: str, timeout: int = 20):
    request = urllib.request.Request(
        url,
        headers={"User-Agent": f"ToutiaoVideoPipeline/{__version__}"},
    )
    return urllib.request.urlopen(request, timeout=timeout)


def fetch_update_info(manifest_url: str = MANIFEST_URL) -> UpdateInfo:
    with _open_request(manifest_url) as response:
        raw = response.read(256_000)
    data = json.loads(raw.decode("utf-8"))
    version = str(data.get("version", "")).strip()
    package_url = str(data.get("package_url", "")).strip()
    sha256 = str(data.get("sha256", "")).strip().lower()
    notes = data.get("release_notes", [])
    if not version or not package_url or not re.fullmatch(r"[0-9a-f]{64}", sha256):
        raise ValueError("GitHub版本信息不完整")
    parsed = urlparse(package_url)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_DOWNLOAD_HOSTS:
        raise ValueError("更新包地址不是受信任的GitHub HTTPS地址")
    if not isinstance(notes, list):
        notes = [str(notes)]
    return UpdateInfo(
        version=version,
        package_url=package_url,
        sha256=sha256,
        release_notes=[str(note) for note in notes if str(note).strip()],
        published_at=str(data.get("published_at", "")),
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_update(
    info: UpdateInfo,
    destination: Path,
    progress: Callable[[int], None] | None = None,
) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".part")
    try:
        with _open_request(info.package_url, timeout=60) as response, temporary.open("wb") as output:
            total = int(response.headers.get("Content-Length") or 0)
            received = 0
            while True:
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                output.write(chunk)
                received += len(chunk)
                if progress and total:
                    progress(min(100, int(received * 100 / total)))
        actual = sha256_file(temporary)
        if actual != info.sha256:
            raise ValueError("更新包校验失败，文件可能未下载完整")
        temporary.replace(destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return destination

