from __future__ import annotations

import os
import traceback
from datetime import datetime
from pathlib import Path


def error_log_path() -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "ToutiaoVideoPipeline"
    else:
        root = Path.home() / ".local" / "share" / "toutiao-video-pipeline"
    root.mkdir(parents=True, exist_ok=True)
    return root / "startup_error.log"


try:
    from toutiao_pipeline.ui import main

    main()
except Exception:
    details = traceback.format_exc()
    log_path = error_log_path()
    log_path.write_text(
        f"头条视频流水线助手启动失败\n时间：{datetime.now().isoformat()}\n\n{details}",
        encoding="utf-8",
    )
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "头条视频流水线助手启动失败",
            "软件没有成功启动。\n\n"
            f"错误日志已经保存到：\n{log_path}\n\n"
            "请把这个日志文件发给我，我可以继续帮你排查。",
        )
        root.destroy()
    except Exception:
        pass

