@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv\Scripts\pythonw.exe (
  echo 请先双击 install_windows.bat 完成安装。
  pause
  exit /b 1
)
if not exist launcher.pyw (
  echo [错误] 缺少 launcher.pyw，请重新下载并完整解压软件。
  pause
  exit /b 1
)
start "" .venv\Scripts\pythonw.exe launcher.pyw

