@echo off
title Toutiao Video Pipeline - Startup Diagnostics
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Run install_windows.bat first.
  pause
  exit /b 1
)
echo Starting the app in diagnostic mode...
echo If an error occurs, details will appear here.
.venv\Scripts\python.exe launcher.pyw
if errorlevel 1 (
  echo.
  echo The app failed to start.
  echo Send a screenshot and the startup_error.log file for troubleshooting.
  pause
)

