@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv\Scripts\pythonw.exe (
  echo 请先双击 install_windows.bat 完成安装。
  pause
  exit /b 1
)
start "" .venv\Scripts\pythonw.exe app.py

