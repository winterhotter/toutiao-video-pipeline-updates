$ErrorActionPreference = "Stop"

$projectRoot = $PSScriptRoot
$pythonw = Join-Path $projectRoot ".venv\Scripts\pythonw.exe"
$launcher = Join-Path $projectRoot "launcher.pyw"

if (-not (Test-Path $pythonw)) {
    throw "pythonw.exe was not found. Run install_windows.bat first."
}

$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "Toutiao Video Pipeline.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $pythonw
$shortcut.Arguments = '"' + $launcher + '"'
$shortcut.WorkingDirectory = $projectRoot
$shortcut.Description = "Toutiao Video Pipeline"
$shortcut.IconLocation = "$env:WINDIR\System32\shell32.dll,220"
$shortcut.Save()

Write-Host "Desktop shortcut created: $shortcutPath"

