@echo off
chcp 65001 >nul
title 打包头条视频流水线助手
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo 请先运行 install_windows.bat。
  pause
  exit /b 1
)
call .venv\Scripts\python.exe -m pip install pyinstaller
call .venv\Scripts\pyinstaller.exe --noconfirm --clean --onefile --windowed --name "头条视频流水线助手" --collect-all yt_dlp --collect-all PIL app.py
echo.
echo 打包完成，程序位于 dist 文件夹。注意：目标电脑仍需安装FFmpeg。
pause

