@echo off
chcp 65001 >nul
title 头条视频流水线助手 - 启动诊断
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo 请先双击 install_windows.bat 完成安装。
  pause
  exit /b 1
)
echo 正在启动软件。如果发生错误，本窗口会显示详细信息……
.venv\Scripts\python.exe launcher.pyw
if errorlevel 1 (
  echo.
  echo 软件启动失败。请把本窗口截图和 startup_error.log 发给我。
  pause
)
