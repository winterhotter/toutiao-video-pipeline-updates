"""Toutiao video preparation desktop workflow."""

__version__ = "0.3.0"
