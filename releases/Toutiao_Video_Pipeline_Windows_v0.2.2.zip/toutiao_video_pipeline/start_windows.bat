@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\pythonw.exe (
  echo Run install_windows.bat first.
  pause
  exit /b 1
)
if not exist launcher.pyw (
  echo [ERROR] launcher.pyw is missing.
  echo Download the complete ZIP again and extract all files.
  pause
  exit /b 1
)
start "" .venv\Scripts\pythonw.exe launcher.pyw

