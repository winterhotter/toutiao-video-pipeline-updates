from __future__ import annotations

import os
import queue
import re
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .database import Database
from .models import JobStatus
from .processor import VideoProcessor, app_data_dir, build_cover_prompt, default_output_root
from .text_ai import parse_metadata_json
from . import __version__
from .update_manager import download_update, fetch_update_info, is_newer_version


URL_PATTERN = re.compile(r"https?://[^\s]+", re.IGNORECASE)


class PipelineApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("头条视频流水线助手")
        self.geometry("1240x840")
        self.minsize(980, 680)

        self.db = Database(app_data_dir() / "workflow.db")
        saved_output = self.db.get_setting("output_root", str(default_output_root()))
        saved_model = self.db.get_setting("openai_model", "gpt-5.6-luna")
        self.output_var = tk.StringVar(value=saved_output)
        self.model_var = tk.StringVar(value=saved_model)
        self.api_key_var = tk.StringVar(value=os.environ.get("OPENAI_API_KEY", ""))
        self.status_var = tk.StringVar(value="就绪")
        self.events: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.worker: threading.Thread | None = None

        self._configure_style()
        self._build_ui()
        self.refresh_jobs()
        self.after(150, self._poll_events)

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        for theme in ("vista", "clam"):
            if theme in style.theme_names():
                style.theme_use(theme)
                break
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 18, "bold"))
        style.configure("Hint.TLabel", foreground="#5b6472")
        style.configure("Primary.TButton", font=("Microsoft YaHei UI", 10, "bold"))
        style.configure("Treeview", rowheight=28, font=("Microsoft YaHei UI", 9))
        style.configure("Treeview.Heading", font=("Microsoft YaHei UI", 9, "bold"))

    def _build_ui(self) -> None:
        root = ttk.Frame(self, padding=16)
        root.pack(fill="both", expand=True)

        ttk.Label(root, text=f"头条视频流水线助手  v{__version__}", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            root,
            text="无API模式：自动准备素材，一键交给ChatGPT生成中文标题和封面，再由软件完成中文封面排版。",
            style="Hint.TLabel",
        ).pack(anchor="w", pady=(2, 12))

        settings = ttk.LabelFrame(root, text="设置", padding=10)
        settings.pack(fill="x")
        settings.columnconfigure(1, weight=1)
        ttk.Label(settings, text="输出目录").grid(row=0, column=0, sticky="w", padx=(0, 8))
        ttk.Entry(settings, textvariable=self.output_var).grid(row=0, column=1, sticky="ew")
        ttk.Button(settings, text="选择…", command=self.choose_output).grid(row=0, column=2, padx=(8, 0))

        ttk.Label(settings, text="OpenAI API密钥（可选）").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=(8, 0))
        ttk.Entry(settings, textvariable=self.api_key_var, show="•").grid(row=1, column=1, sticky="ew", pady=(8, 0))
        ttk.Label(settings, text="不填也能使用下方的ChatGPT会员模式", style="Hint.TLabel").grid(
            row=1, column=2, sticky="w", padx=(8, 0), pady=(8, 0)
        )

        ttk.Label(settings, text="文字模型").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=(8, 0))
        model_box = ttk.Combobox(
            settings,
            textvariable=self.model_var,
            values=("gpt-5.6-luna", "gpt-5.6-terra", "gpt-5.6"),
        )
        model_box.grid(row=2, column=1, sticky="w", pady=(8, 0))
        ttk.Button(settings, text="保存设置", command=self.save_settings).grid(row=2, column=2, padx=(8, 0), pady=(8, 0))

        add_box = ttk.LabelFrame(root, text="1. 添加视频", padding=10)
        add_box.pack(fill="x", pady=(12, 0))
        add_box.columnconfigure(0, weight=1)
        self.url_text = tk.Text(add_box, height=4, wrap="word", font=("Microsoft YaHei UI", 10))
        self.url_text.grid(row=0, column=0, columnspan=3, sticky="ew")
        self.url_text.insert("1.0", "每行粘贴一个YouTube链接，可一次添加多个")
        self.url_text.bind("<FocusIn>", self._clear_placeholder, add="+")

        ttk.Label(
            add_box,
            text="粘贴到这里的视频默认记录为：已获得版权授权",
            style="Hint.TLabel",
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(8, 0))
        ttk.Button(add_box, text="加入队列", command=self.add_urls).grid(row=1, column=2, pady=(8, 0))

        actions = ttk.Frame(root)
        actions.pack(fill="x", pady=12)
        self.start_button = ttk.Button(
            actions, text="2. 开始批量处理", style="Primary.TButton", command=self.start_processing
        )
        self.start_button.pack(side="left")
        ttk.Button(actions, text="刷新列表", command=self.refresh_jobs).pack(side="left", padx=8)
        ttk.Button(actions, text="打开ChatGPT", command=lambda: webbrowser.open("https://chatgpt.com/")).pack(side="left")
        ttk.Button(actions, text="检查更新", command=self.check_for_updates).pack(side="left", padx=8)
        ttk.Label(actions, textvariable=self.status_var).pack(side="right")

        table_box = ttk.LabelFrame(root, text="3. 封面与发布队列", padding=8)
        table_box.pack(fill="both", expand=True)
        table_box.rowconfigure(0, weight=1)
        table_box.columnconfigure(0, weight=1)
        columns = ("id", "title", "status", "author", "error")
        self.tree = ttk.Treeview(table_box, columns=columns, show="headings", selectmode="browse")
        headings = {"id": "编号", "title": "中文标题", "status": "状态", "author": "来源", "error": "提示"}
        widths = {"id": 65, "title": 370, "status": 145, "author": 170, "error": 270}
        for name in columns:
            self.tree.heading(name, text=headings[name])
            self.tree.column(name, width=widths[name], stretch=name in {"title", "error"})
        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(table_box, orient="vertical", command=self.tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.tag_configure("error", foreground="#b42318")
        self.tree.tag_configure("ready", foreground="#087443")

        row_actions = ttk.Frame(table_box)
        row_actions.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        ttk.Button(
            row_actions,
            text="① 用ChatGPT生成标题+封面",
            style="Primary.TButton",
            command=self.start_no_api_chatgpt,
        ).pack(side="left")
        ttk.Button(row_actions, text="② 粘贴ChatGPT标题结果", command=self.paste_chatgpt_result).pack(side="left", padx=6)
        ttk.Button(row_actions, text="③ 导入最新下载封面", command=self.import_latest_cover).pack(side="left")

        secondary_actions = ttk.Frame(table_box)
        secondary_actions.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        ttk.Button(secondary_actions, text="编辑标题和简介", command=self.edit_metadata).pack(side="left")
        ttk.Button(secondary_actions, text="选择其他封面图片", command=self.import_cover).pack(side="left", padx=6)
        ttk.Button(secondary_actions, text="打开视频文件夹", command=self.open_job_folder).pack(side="left")
        ttk.Button(secondary_actions, text="标记已发布", command=self.mark_published).pack(side="left", padx=6)

        log_box = ttk.LabelFrame(root, text="运行记录", padding=6)
        log_box.pack(fill="x", pady=(10, 0))
        self.log_text = tk.Text(log_box, height=5, state="disabled", wrap="word", font=("Consolas", 9))
        self.log_text.pack(fill="x")

    def _clear_placeholder(self, _event: tk.Event) -> None:
        if self.url_text.get("1.0", "end").strip().startswith("每行粘贴"):
            self.url_text.delete("1.0", "end")

    def choose_output(self) -> None:
        chosen = filedialog.askdirectory(initialdir=self.output_var.get() or str(Path.home()))
        if chosen:
            self.output_var.set(chosen)
            self.save_settings(show_message=False)

    def save_settings(self, show_message: bool = True) -> None:
        output = self.output_var.get().strip()
        model = self.model_var.get().strip() or "gpt-5.6-luna"
        if not output:
            messagebox.showerror("设置", "请选择输出目录")
            return
        self.db.set_setting("output_root", output)
        self.db.set_setting("openai_model", model)
        if show_message:
            messagebox.showinfo("设置", "设置已保存。API密钥不会保存。")

    def add_urls(self) -> None:
        rights_note = "默认已获得版权授权"
        urls = [url.rstrip(".,;，。；") for url in URL_PATTERN.findall(self.url_text.get("1.0", "end"))]
        if not urls:
            messagebox.showwarning("没有链接", "请至少粘贴一个完整的http或https链接。")
            return
        created = duplicates = 0
        for url in dict.fromkeys(urls):
            _, is_new = self.db.add_job(url, rights_note)
            created += int(is_new)
            duplicates += int(not is_new)
        self.url_text.delete("1.0", "end")
        self.log(f"新增 {created} 条，已存在 {duplicates} 条；重复链接不会再次建立任务。")
        self.refresh_jobs()

    def start_processing(self) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("正在运行", "批量任务仍在处理，请稍候。")
            return
        missing = VideoProcessor.check_dependencies()
        if missing:
            messagebox.showerror("缺少组件", "请先运行 install_windows.bat。缺少：" + "、".join(missing))
            return
        jobs = self.db.list_processable()
        if not jobs:
            messagebox.showinfo("没有任务", "没有等待处理或处理失败的任务。")
            return
        self.save_settings(show_message=False)
        output = Path(self.output_var.get()).expanduser()
        api_key = self.api_key_var.get().strip()
        model = self.model_var.get().strip() or "gpt-5.6-luna"
        if not api_key:
            proceed = messagebox.askyesno(
                "使用无API的ChatGPT会员模式",
                "软件会先下载视频并提取参考图。处理完成后，选中视频并点击“① 用ChatGPT生成标题+封面”。\n\n继续吗？",
            )
            if not proceed:
                return
        self.start_button.configure(state="disabled")
        self.status_var.set(f"正在处理 {len(jobs)} 条任务")
        self.worker = threading.Thread(
            target=self._process_worker,
            args=([job.id for job in jobs], output, api_key, model),
            daemon=True,
        )
        self.worker.start()

    def _process_worker(self, job_ids: list[int], output: Path, api_key: str, model: str) -> None:
        processor = VideoProcessor(self.db, output)
        for job_id in job_ids:
            processor.process_job(
                job_id,
                api_key=api_key,
                model=model,
                progress=lambda message: self.events.put(("log", message)),
            )
            self.events.put(("refresh", ""))
        self.events.put(("done", "批量处理完成"))

    def _poll_events(self) -> None:
        try:
            while True:
                event, payload = self.events.get_nowait()
                if event == "log":
                    self.log(payload)
                elif event == "refresh":
                    self.refresh_jobs()
                elif event == "done":
                    self.start_button.configure(state="normal")
                    self.status_var.set(payload)
                    self.refresh_jobs()
                elif event == "update_result":
                    self._show_update_result(payload)
                elif event == "update_error":
                    self.status_var.set("检查更新失败")
                    messagebox.showerror("检查更新失败", str(payload))
                elif event == "update_progress":
                    self.status_var.set(f"正在下载更新：{payload}%")
                elif event == "update_downloaded":
                    self.status_var.set("更新包已下载")
                    path = Path(payload)
                    messagebox.showinfo(
                        "下载完成",
                        "更新包已经通过完整性校验。\n\n"
                        "请关闭软件，解压下载的ZIP并覆盖原程序文件，然后再次运行 install_windows.bat。",
                    )
                    self._open_path(path.parent)
                elif event == "update_download_error":
                    self.status_var.set("更新下载失败")
                    messagebox.showerror("下载更新失败", str(payload))
        except queue.Empty:
            pass
        self.after(150, self._poll_events)

    def refresh_jobs(self) -> None:
        selected = self.selected_job_id(silent=True)
        self.tree.delete(*self.tree.get_children())
        for job in self.db.list_jobs():
            tag = "error" if job.status == JobStatus.ERROR.value else (
                "ready" if job.status in {JobStatus.READY_TO_PUBLISH.value, JobStatus.PUBLISHED.value} else ""
            )
            item = self.tree.insert(
                "",
                "end",
                iid=str(job.id),
                values=(
                    f"V{job.id:04d}",
                    job.chinese_title or job.original_title or "等待读取",
                    job.status,
                    job.source_author,
                    job.error_message,
                ),
                tags=(tag,) if tag else (),
            )
            if selected == job.id:
                self.tree.selection_set(item)

    def check_for_updates(self) -> None:
        self.status_var.set("正在连接GitHub检查更新…")

        def worker() -> None:
            try:
                info = fetch_update_info()
                self.events.put(("update_result", info))
            except Exception as exc:
                self.events.put(("update_error", exc))

        threading.Thread(target=worker, daemon=True).start()

    def _show_update_result(self, info) -> None:
        if not is_newer_version(info.version):
            self.status_var.set("当前已是最新版")
            messagebox.showinfo(
                "检查更新",
                f"当前版本：v{__version__}\nGitHub最新版本：v{info.version}\n\n当前已经是最新版。",
            )
            return
        self.status_var.set(f"发现新版本 v{info.version}")
        notes = "\n".join(f"• {note}" for note in info.release_notes) or "• 常规功能更新"
        should_download = messagebox.askyesno(
            "发现新版本",
            f"当前版本：v{__version__}\n最新版本：v{info.version}\n\n更新内容：\n{notes}\n\n现在下载更新包吗？",
        )
        if not should_download:
            return
        downloads = Path.home() / "Downloads"
        if not downloads.exists():
            downloads = Path.home()
        target = downloads / f"Toutiao_Video_Pipeline_Windows_v{info.version}.zip"

        def worker() -> None:
            try:
                result = download_update(
                    info,
                    target,
                    progress=lambda percent: self.events.put(("update_progress", percent)),
                )
                self.events.put(("update_downloaded", str(result)))
            except Exception as exc:
                self.events.put(("update_download_error", exc))

        threading.Thread(target=worker, daemon=True).start()

    def selected_job_id(self, silent: bool = False) -> int | None:
        selection = self.tree.selection() if hasattr(self, "tree") else ()
        if not selection:
            if not silent:
                messagebox.showinfo("请选择任务", "请先在列表中选择一条视频。")
            return None
        return int(selection[0])

    def copy_cover_prompt(self) -> None:
        job_id = self.selected_job_id()
        if job_id is None:
            return
        job = self.db.get_job(job_id)
        if not job or not job.cover_prompt:
            messagebox.showinfo("尚未准备", "请先完成该视频的自动处理。")
            return
        self.clipboard_clear()
        self.clipboard_append(job.cover_prompt)
        self.update()
        self.log(f"已复制视频 #{job_id} 的ChatGPT封面提示词。")

    def start_no_api_chatgpt(self) -> None:
        job_id = self.selected_job_id()
        if job_id is None:
            return
        job = self.db.get_job(job_id)
        if not job or not job.folder or not job.folder.exists():
            messagebox.showinfo("尚未准备", "请先点击“开始批量处理”，完成视频下载和参考图提取。")
            return
        try:
            output = Path(self.output_var.get()).expanduser()
            prompt = VideoProcessor(self.db, output).get_no_api_prompt(job_id)
        except Exception as exc:
            messagebox.showerror("无法准备ChatGPT任务", str(exc))
            return
        self.clipboard_clear()
        self.clipboard_append(prompt)
        self.update()
        self._open_path(job.folder)
        webbrowser.open("https://chatgpt.com/")
        self.log(f"视频 #{job_id}：一键任务提示词已复制，ChatGPT和参考图文件夹已打开。")
        messagebox.showinfo(
            "下一步只做三件事",
            "1. 在刚打开的文件夹找到“封面参考图.jpg”，拖进ChatGPT。\n"
            "2. 在ChatGPT输入框按 Ctrl+V 粘贴提示词并发送。\n"
            "3. ChatGPT返回JSON后复制JSON；图片生成后点击下载。\n\n"
            "然后回到软件，依次点击步骤②和③。",
        )

    def paste_chatgpt_result(self) -> None:
        job_id = self.selected_job_id()
        if job_id is None:
            return
        try:
            raw = self.clipboard_get()
            metadata = parse_metadata_json(raw)
            output = Path(self.output_var.get()).expanduser()
            VideoProcessor(self.db, output).apply_metadata(job_id, metadata)
        except Exception as exc:
            messagebox.showerror(
                "无法读取ChatGPT结果",
                "请在ChatGPT回复中复制完整JSON代码块，然后再点击这个按钮。\n\n"
                f"详细信息：{exc}",
            )
            return
        self.refresh_jobs()
        self.log(f"视频 #{job_id}：已自动填入中文标题、备选标题、简介和标签。")
        messagebox.showinfo(
            "中文信息已填入",
            f"主标题：{metadata.primary_title}\n\n"
            "现在等待ChatGPT图片生成完成，点击图片的下载按钮，然后回软件点击步骤③。",
        )

    def import_latest_cover(self) -> None:
        job_id = self.selected_job_id()
        if job_id is None:
            return
        downloads = Path.home() / "Downloads"
        extensions = {".png", ".jpg", ".jpeg", ".webp"}
        candidates: list[Path] = []
        if downloads.exists():
            candidates = [
                path for path in downloads.iterdir()
                if path.is_file() and path.suffix.lower() in extensions
            ]
        candidates.sort(key=lambda path: path.stat().st_mtime, reverse=True)
        source = candidates[0] if candidates else None
        if source is None or time.time() - source.stat().st_mtime > 4 * 3600:
            messagebox.showinfo("没有找到新图片", "下载文件夹中没有最近4小时内的图片，请手动选择。")
            self.import_cover()
            return
        if not messagebox.askyesno(
            "确认最新封面",
            f"找到下载文件夹中最新的图片：\n\n{source.name}\n\n使用这张图片生成三套中文封面吗？",
        ):
            self.import_cover()
            return
        self._import_cover_path(job_id, source)

    def edit_metadata(self) -> None:
        job_id = self.selected_job_id()
        if job_id is None:
            return
        job = self.db.get_job(job_id)
        if not job or not job.folder:
            messagebox.showinfo("尚未准备", "请先完成该视频的自动处理。")
            return

        dialog = tk.Toplevel(self)
        dialog.title(f"编辑 V{job.id:04d}")
        dialog.geometry("720x540")
        dialog.transient(self)
        dialog.grab_set()
        frame = ttk.Frame(dialog, padding=16)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)

        title_var = tk.StringVar(value=job.chinese_title)
        tags_var = tk.StringVar(value=job.tags)
        ttk.Label(frame, text="主标题").grid(row=0, column=0, sticky="nw", padx=(0, 8))
        ttk.Entry(frame, textvariable=title_var).grid(row=0, column=1, sticky="ew")
        ttk.Label(frame, text="建议30个汉字以内；导入封面时会自动叠加这个标题。", style="Hint.TLabel").grid(
            row=1, column=1, sticky="w", pady=(3, 10)
        )
        ttk.Label(frame, text="AI备选标题").grid(row=2, column=0, sticky="nw", padx=(0, 8))
        alternatives = tk.Text(frame, height=4, wrap="word")
        alternatives.grid(row=2, column=1, sticky="ew")
        alternatives.insert("1.0", job.alternative_titles)
        ttk.Label(frame, text="简介").grid(row=3, column=0, sticky="nw", padx=(0, 8), pady=(10, 0))
        description = tk.Text(frame, height=10, wrap="word")
        description.grid(row=3, column=1, sticky="nsew", pady=(10, 0))
        description.insert("1.0", job.description)
        frame.rowconfigure(3, weight=1)
        ttk.Label(frame, text="标签").grid(row=4, column=0, sticky="nw", padx=(0, 8), pady=(10, 0))
        ttk.Entry(frame, textvariable=tags_var).grid(row=4, column=1, sticky="ew", pady=(10, 0))

        def save() -> None:
            title = title_var.get().strip()
            if not title:
                messagebox.showwarning("标题", "主标题不能为空。", parent=dialog)
                return
            desc = description.get("1.0", "end").strip()
            tags = tags_var.get().replace("#", "").replace("，", ",").strip()
            prompt = build_cover_prompt(title, job.original_title, desc)
            self.db.update_job(
                job.id,
                chinese_title=title,
                alternative_titles=alternatives.get("1.0", "end").strip(),
                description=desc,
                tags=tags,
                cover_prompt=prompt,
            )
            titles = [f"主标题：{title}"]
            for index, alt in enumerate(filter(None, alternatives.get("1.0", "end").splitlines()), 1):
                titles.append(f"备选{index}：{alt.strip()}")
            job.folder.joinpath("标题.txt").write_text("\n".join(titles) + "\n", encoding="utf-8")
            tag_line = " ".join(f"#{tag.strip()}" for tag in tags.split(",") if tag.strip())
            job.folder.joinpath("简介.txt").write_text(f"{desc}\n\n{tag_line}".strip() + "\n", encoding="utf-8")
            job.folder.joinpath("ChatGPT封面提示词.txt").write_text(prompt + "\n", encoding="utf-8")
            self.log(f"视频 #{job.id} 的标题和简介已更新。")
            self.refresh_jobs()
            dialog.destroy()

        buttons = ttk.Frame(frame)
        buttons.grid(row=5, column=1, sticky="e", pady=(14, 0))
        ttk.Button(buttons, text="取消", command=dialog.destroy).pack(side="left")
        ttk.Button(buttons, text="保存", style="Primary.TButton", command=save).pack(side="left", padx=(8, 0))

    def import_cover(self) -> None:
        job_id = self.selected_job_id()
        if job_id is None:
            return
        source = filedialog.askopenfilename(
            title="选择ChatGPT生成的封面",
            filetypes=[("图片", "*.png *.jpg *.jpeg *.webp"), ("所有文件", "*.*")],
        )
        if not source:
            return
        self._import_cover_path(job_id, Path(source))

    def _import_cover_path(self, job_id: int, source: Path) -> None:
        try:
            output = Path(self.output_var.get()).expanduser()
            target = VideoProcessor(self.db, output).import_cover(job_id, source)
        except Exception as exc:
            messagebox.showerror("导入失败", str(exc))
            return
        job = self.db.get_job(job_id)
        self.log(f"封面已生成：{target}；同时生成三张16:9候选封面。")
        self.refresh_jobs()
        messagebox.showinfo(
            "封面生成完成",
            "已经生成：\n"
            "• 默认头条宽幅封面 cover.jpg\n"
            "• 红黄爆款16:9\n"
            "• 金色挑战16:9\n"
            "• 白红冲击16:9\n\n"
            "文件夹即将打开，请选择你最喜欢的一张。",
        )
        if job and job.folder:
            self._open_path(job.folder)

    def open_job_folder(self) -> None:
        job_id = self.selected_job_id()
        if job_id is None:
            return
        job = self.db.get_job(job_id)
        if not job or not job.folder or not job.folder.exists():
            messagebox.showinfo("没有文件夹", "请先处理这条视频。")
            return
        self._open_path(job.folder)

    @staticmethod
    def _open_path(path: Path) -> None:
        if os.name == "nt":
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])

    def mark_published(self) -> None:
        job_id = self.selected_job_id()
        if job_id is None:
            return
        job = self.db.get_job(job_id)
        if not job:
            return
        if job.status != JobStatus.READY_TO_PUBLISH.value:
            if not messagebox.askyesno("确认状态", "该任务尚未显示“可以发布”，仍要标记为已发布吗？"):
                return
        self.db.update_job(job_id, status=JobStatus.PUBLISHED.value)
        self.log(f"视频 #{job_id} 已标记为发布，今后加入相同链接会提示重复。")
        self.refresh_jobs()

    def log(self, message: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")


def main() -> None:
    app = PipelineApp()
    app.mainloop()
