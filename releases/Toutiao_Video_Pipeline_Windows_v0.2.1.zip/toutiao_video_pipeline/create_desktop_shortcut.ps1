$ErrorActionPreference = "Stop"

$projectRoot = $PSScriptRoot
$pythonw = Join-Path $projectRoot ".venv\Scripts\pythonw.exe"
$launcher = Join-Path $projectRoot "launcher.pyw"

if (-not (Test-Path $pythonw)) {
    throw "没有找到 $pythonw，请先完成Python环境安装。"
}

$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "头条视频流水线助手.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $pythonw
$shortcut.Arguments = '"' + $launcher + '"'
$shortcut.WorkingDirectory = $projectRoot
$shortcut.Description = "头条视频流水线助手"
$shortcut.IconLocation = "$env:WINDIR\System32\shell32.dll,220"
$shortcut.Save()

Write-Host "桌面快捷方式已创建：$shortcutPath"

