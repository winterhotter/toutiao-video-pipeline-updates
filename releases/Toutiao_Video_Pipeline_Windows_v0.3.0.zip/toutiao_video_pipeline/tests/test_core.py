from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from toutiao_pipeline.database import Database
from toutiao_pipeline.models import JobStatus
from toutiao_pipeline.processor import build_cover_prompt, safe_filename
from toutiao_pipeline.text_ai import parse_metadata_json
from toutiao_pipeline.update_manager import is_newer_version, version_tuple
from toutiao_pipeline.chatgpt_handoff import build_no_api_chatgpt_prompt


class CoreTests(unittest.TestCase):
    def test_safe_filename_removes_windows_reserved_characters(self) -> None:
        name = safe_filename('ASMR: a/b <c> "d" | e? *')
        for character in '<>:"/\\|?*':
            self.assertNotIn(character, name)

    def test_parse_metadata_accepts_fenced_json(self) -> None:
        metadata = parse_metadata_json(
            '```json\n{"primary_title":"巧克力麻薯挑战",'
            '"alternative_titles":["备选一","备选二"],'
            '"description":"简介", "tags":["#ASMR","甜品"]}\n```'
        )
        self.assertEqual(metadata.primary_title, "巧克力麻薯挑战")
        self.assertEqual(metadata.alternative_titles, ["备选一", "备选二"])
        self.assertEqual(metadata.tags, ["ASMR", "甜品"])

    def test_database_deduplicates_source_urls(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            db = Database(Path(directory) / "workflow.db")
            first, first_created = db.add_job("https://example.com/watch?v=1", "本人原创")
            duplicate, duplicate_created = db.add_job("https://example.com/watch?v=1", "本人原创")
            self.assertTrue(first_created)
            self.assertFalse(duplicate_created)
            self.assertEqual(first.id, duplicate.id)
            self.assertEqual(duplicate.status, JobStatus.QUEUED.value)

    def test_cover_prompt_requests_no_text(self) -> None:
        prompt = build_cover_prompt("中文标题", "Original title", "food")
        self.assertIn("不添加任何文字", prompt)
        self.assertIn("2.35:1", prompt)

    def test_semantic_version_comparison(self) -> None:
        self.assertEqual(version_tuple("v1.2.10"), (1, 2, 10))
        self.assertTrue(is_newer_version("0.2.0", "0.1.9"))
        self.assertFalse(is_newer_version("0.2.0", "0.2.0"))
        self.assertFalse(is_newer_version("0.1.9", "0.2.0"))

    def test_no_api_prompt_requests_metadata_and_clean_cover(self) -> None:
        prompt = build_no_api_chatgpt_prompt("ASMR dessert race", "Creator", "Desserts")
        self.assertIn('"primary_title"', prompt)
        self.assertIn("不超过30个汉字", prompt)
        self.assertIn("不要添加任何文字", prompt)
        self.assertIn("16:9", prompt)


if __name__ == "__main__":
    unittest.main()
