from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass(slots=True)
class ChineseMetadata:
    primary_title: str
    alternative_titles: list[str]
    description: str
    tags: list[str]


def build_metadata_prompt(original_title: str, author: str, description: str) -> str:
    excerpt = (description or "")[:2500]
    return f"""你是一名今日头条视频编辑。请根据原始信息生成自然、准确、有吸引力的中文发布信息。

要求：
1. 不虚构视频中没有的食物、人物、比赛结果或情节。
2. 主标题不超过30个汉字，适合今日头条，但不要使用虚假夸张词。
3. 再提供两个不同角度的备选标题。
4. 简介为80至150个中文字符，口语化并说明视频看点。
5. 给出5至8个简短标签，不带#号。
6. 只返回有效JSON，不要Markdown，结构如下：
{{"primary_title":"", "alternative_titles":["", ""], "description":"", "tags":[""]}}

原始标题：{original_title}
原作者/频道：{author}
原始简介：{excerpt}
"""


def fallback_metadata(original_title: str, author: str) -> ChineseMetadata:
    title = original_title.strip() or "待补充中文标题"
    return ChineseMetadata(
        primary_title=title,
        alternative_titles=[],
        description=f"视频来源：{author or '原作者'}。请发布前补充中文简介并核对授权信息。",
        tags=[],
    )


def parse_metadata_json(raw: str) -> ChineseMetadata:
    text = raw.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lstrip().startswith("json"):
            text = text.lstrip()[4:].lstrip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("AI返回内容不是有效JSON")
        data = json.loads(text[start : end + 1])
    title = str(data.get("primary_title", "")).strip()
    if not title:
        raise ValueError("AI没有返回主标题")
    alternatives = [str(x).strip() for x in data.get("alternative_titles", []) if str(x).strip()]
    tags = [str(x).strip().lstrip("#") for x in data.get("tags", []) if str(x).strip()]
    return ChineseMetadata(
        primary_title=title,
        alternative_titles=alternatives[:2],
        description=str(data.get("description", "")).strip(),
        tags=tags[:8],
    )


def generate_metadata(
    *, api_key: str, model: str, original_title: str, author: str, description: str
) -> ChineseMetadata:
    if not api_key:
        return fallback_metadata(original_title, author)
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("缺少openai组件，请先运行安装脚本") from exc
    client = OpenAI(api_key=api_key)
    response = client.responses.create(
        model=model,
        input=build_metadata_prompt(original_title, author, description),
        reasoning={"effort": "low"},
        text={"verbosity": "low"},
    )
    return parse_metadata_json(response.output_text)

