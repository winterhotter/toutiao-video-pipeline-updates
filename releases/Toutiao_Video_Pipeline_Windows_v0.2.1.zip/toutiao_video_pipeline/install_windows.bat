@echo off
chcp 65001 >nul
title 安装头条视频流水线助手
cd /d "%~dp0"

where py >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [错误] 没有检测到Python。
    echo 请先从 https://www.python.org/downloads/windows/ 安装Python 3.11或更新版本。
    echo 安装时必须勾选 Add Python to PATH。
    pause
    exit /b 1
  )
  set "PYTHON_CMD=python"
)

if not exist .venv (
  echo 正在创建本地运行环境……
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 goto :failed
)

echo 正在安装所需组件……
call .venv\Scripts\python.exe -m pip install --upgrade pip
call .venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :failed

where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo.
  echo 没有检测到FFmpeg。正在尝试使用winget安装……
  where winget >nul 2>nul
  if errorlevel 1 (
    echo [提示] 请手动安装FFmpeg，并确保ffmpeg.exe在PATH中。
    echo 推荐命令：winget install --id Gyan.FFmpeg -e
  ) else (
    winget install --id Gyan.FFmpeg -e --accept-package-agreements --accept-source-agreements
  )
)

echo.
echo 正在创建桌面快捷方式……
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_desktop_shortcut.ps1"
if errorlevel 1 (
  echo [提示] 桌面快捷方式创建失败，但软件仍可通过 start_windows.bat 启动。
)

echo.
echo 安装完成。
echo 以后可以双击桌面的“头条视频流水线助手”启动。
echo 如果桌面图标没有出现，也可以双击 start_windows.bat。
pause
exit /b 0

:failed
echo.
echo [错误] 安装没有完成，请截图本窗口发给我排查。
pause
exit /b 1
