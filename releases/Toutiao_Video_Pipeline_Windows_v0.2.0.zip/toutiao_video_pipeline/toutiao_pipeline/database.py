from __future__ import annotations

import sqlite3
from pathlib import Path

from .models import JobStatus, VideoJob


class Database:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_url TEXT NOT NULL UNIQUE,
                    rights_note TEXT NOT NULL,
                    status TEXT NOT NULL,
                    original_title TEXT NOT NULL DEFAULT '',
                    chinese_title TEXT NOT NULL DEFAULT '',
                    alternative_titles TEXT NOT NULL DEFAULT '',
                    description TEXT NOT NULL DEFAULT '',
                    tags TEXT NOT NULL DEFAULT '',
                    source_author TEXT NOT NULL DEFAULT '',
                    source_license TEXT NOT NULL DEFAULT '',
                    output_dir TEXT NOT NULL DEFAULT '',
                    cover_prompt TEXT NOT NULL DEFAULT '',
                    error_message TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )

    @staticmethod
    def _row_to_job(row: sqlite3.Row) -> VideoJob:
        return VideoJob(**dict(row))

    def add_job(self, source_url: str, rights_note: str) -> tuple[VideoJob, bool]:
        with self._connect() as conn:
            try:
                cur = conn.execute(
                    "INSERT INTO jobs(source_url, rights_note, status) VALUES (?, ?, ?)",
                    (source_url, rights_note, JobStatus.QUEUED.value),
                )
                job_id = cur.lastrowid
                created = True
            except sqlite3.IntegrityError:
                row = conn.execute(
                    "SELECT * FROM jobs WHERE source_url = ?", (source_url,)
                ).fetchone()
                return self._row_to_job(row), False
            row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
            return self._row_to_job(row), created

    def get_job(self, job_id: int) -> VideoJob | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
            return self._row_to_job(row) if row else None

    def list_jobs(self) -> list[VideoJob]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM jobs ORDER BY id DESC").fetchall()
            return [self._row_to_job(row) for row in rows]

    def list_processable(self) -> list[VideoJob]:
        states = (JobStatus.QUEUED.value, JobStatus.ERROR.value)
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM jobs WHERE status IN (?, ?) ORDER BY id", states
            ).fetchall()
            return [self._row_to_job(row) for row in rows]

    def update_job(self, job_id: int, **fields: str) -> None:
        allowed = {
            "rights_note", "status", "original_title", "chinese_title",
            "alternative_titles", "description", "tags", "source_author",
            "source_license", "output_dir", "cover_prompt", "error_message",
        }
        clean = {key: value for key, value in fields.items() if key in allowed}
        if not clean:
            return
        assignments = ", ".join(f"{key} = ?" for key in clean)
        values = [*clean.values(), job_id]
        with self._connect() as conn:
            conn.execute(
                f"UPDATE jobs SET {assignments}, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                values,
            )

    def get_setting(self, key: str, default: str = "") -> str:
        with self._connect() as conn:
            row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
            return row[0] if row else default

    def set_setting(self, key: str, value: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO settings(key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, value),
            )

