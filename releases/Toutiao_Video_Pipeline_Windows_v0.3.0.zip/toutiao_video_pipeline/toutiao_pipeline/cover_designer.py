from __future__ import annotations

import os
import random
from pathlib import Path


STYLES = (
    {"name": "红黄爆款", "colors": ((255, 225, 35), (255, 55, 20)), "ribbon": (225, 20, 45)},
    {"name": "金色挑战", "colors": ((255, 250, 220), (255, 155, 0)), "ribbon": (165, 15, 20)},
    {"name": "白红冲击", "colors": ((255, 255, 255), (255, 25, 35)), "ribbon": (235, 35, 95)},
)


def find_chinese_font() -> Path | None:
    candidates = [
        Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "msyhbd.ttc",
        Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "simhei.ttf",
        Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "msyh.ttc",
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"),
        Path("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ]
    return next((path for path in candidates if path.exists()), None)


def _split_title(title: str) -> list[str]:
    clean = title.strip().replace("！", "").replace("!", "")
    if len(clean) <= 10:
        return [clean]
    if len(clean) <= 20:
        pivot = len(clean) // 2
        return [clean[:pivot], clean[pivot:]]
    pivot = min(12, max(9, len(clean) // 2))
    return [clean[:pivot], clean[pivot:24]]


def _fit_font(draw, lines: list[str], font_path: Path, max_width: int, start: int, minimum: int):
    from PIL import ImageFont

    for size in range(start, minimum - 1, -2):
        font = ImageFont.truetype(str(font_path), size=size)
        widths = [draw.textbbox((0, 0), line, font=font, stroke_width=8)[2] for line in lines]
        if max(widths, default=0) <= max_width:
            return font
    return ImageFont.truetype(str(font_path), size=minimum)


def _add_dark_focus(image):
    from PIL import Image, ImageDraw

    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    width, height = image.size
    focus_height = int(height * 0.54)
    for y in range(focus_height):
        alpha = int(175 * (1 - y / focus_height)) + 25
        draw.line((0, y, width, y), fill=(0, 0, 0, min(200, alpha)))
    return Image.alpha_composite(image.convert("RGBA"), layer)


def _draw_sparks(draw, width: int, height: int, seed: int) -> None:
    rng = random.Random(seed)
    for _ in range(16):
        x = rng.randint(18, width - 18)
        y = rng.randint(18, int(height * 0.72))
        radius = rng.choice((2, 3, 5, 7))
        color = rng.choice(((255, 215, 45, 220), (255, 255, 255, 230), (255, 100, 15, 220)))
        draw.line((x - radius * 2, y, x + radius * 2, y), fill=color, width=max(1, radius // 2))
        draw.line((x, y - radius * 2, x, y + radius * 2), fill=color, width=max(1, radius // 2))


def _draw_cover(base_image, title: str, subtitle: str, size: tuple[int, int], style: dict, seed: int):
    from PIL import Image, ImageDraw, ImageFont, ImageOps

    font_path = find_chinese_font()
    if font_path is None:
        raise RuntimeError("没有找到可用的中文字体")
    image = ImageOps.fit(
        ImageOps.exif_transpose(base_image).convert("RGB"),
        size,
        method=Image.Resampling.LANCZOS,
        centering=(0.5, 0.5),
    )
    image = _add_dark_focus(image)
    draw = ImageDraw.Draw(image, "RGBA")
    width, height = size
    _draw_sparks(draw, width, height, seed)

    lines = _split_title(title)
    font = _fit_font(draw, lines, font_path, int(width * 0.9), int(height * 0.14), int(height * 0.075))
    line_gap = int(height * 0.012)
    boxes = [draw.textbbox((0, 0), line, font=font, stroke_width=10) for line in lines]
    line_heights = [box[3] - box[1] for box in boxes]
    total_height = sum(line_heights) + line_gap * max(0, len(lines) - 1)
    y = int(height * 0.035)
    if total_height > int(height * 0.34):
        y = int(height * 0.018)

    for index, (line, box) in enumerate(zip(lines, boxes)):
        text_width = box[2] - box[0]
        x = (width - text_width) // 2
        shadow = max(4, int(height * 0.012))
        draw.text(
            (x + shadow, y + shadow), line, font=font,
            fill=(0, 0, 0, 255), stroke_width=max(9, int(height * 0.016)), stroke_fill=(0, 0, 0, 255),
        )
        color = style["colors"][index % len(style["colors"])]
        draw.text(
            (x, y), line, font=font,
            fill=(*color, 255), stroke_width=max(5, int(height * 0.009)), stroke_fill=(255, 245, 215, 255),
        )
        y += line_heights[index] + line_gap

    ribbon_font = ImageFont.truetype(str(font_path), size=max(20, int(height * 0.048)))
    subtitle = subtitle[:24]
    ribbon_box = draw.textbbox((0, 0), subtitle, font=ribbon_font, stroke_width=2)
    ribbon_width = min(int(width * 0.72), ribbon_box[2] - ribbon_box[0] + int(width * 0.08))
    ribbon_height = int(height * 0.085)
    ribbon_x = (width - ribbon_width) // 2
    ribbon_y = min(int(height * 0.42), y + int(height * 0.01))
    draw.rounded_rectangle(
        (ribbon_x, ribbon_y, ribbon_x + ribbon_width, ribbon_y + ribbon_height),
        radius=int(ribbon_height * 0.35),
        fill=(*style["ribbon"], 235), outline=(255, 220, 60, 255), width=max(2, int(height * 0.005)),
    )
    text_x = (width - (ribbon_box[2] - ribbon_box[0])) // 2
    text_y = ribbon_y + (ribbon_height - (ribbon_box[3] - ribbon_box[1])) // 2 - ribbon_box[1]
    draw.text(
        (text_x, text_y), subtitle, font=ribbon_font,
        fill=(255, 255, 255, 255), stroke_width=2, stroke_fill=(75, 0, 0, 255),
    )

    badge_size = int(height * 0.18)
    bx, by = int(width * 0.025), int(height * 0.72)
    draw.ellipse(
        (bx, by, bx + badge_size, by + badge_size),
        fill=(220, 20, 55, 245), outline=(255, 230, 55, 255), width=max(3, int(height * 0.007)),
    )
    badge_font = ImageFont.truetype(str(font_path), size=max(18, int(badge_size * 0.27)))
    for idx, line in enumerate(("ASMR", "吃播")):
        b = draw.textbbox((0, 0), line, font=badge_font, stroke_width=2)
        tx = bx + (badge_size - (b[2] - b[0])) // 2
        ty = by + int(badge_size * (0.18 + idx * 0.34))
        draw.text((tx, ty), line, font=badge_font, fill=(255, 235, 30, 255), stroke_width=2, stroke_fill=(0, 0, 0, 255))
    return image.convert("RGB")


def generate_cover_variants(
    source: Path,
    output_folder: Path,
    title: str,
    tags: list[str] | None = None,
) -> list[Path]:
    from PIL import Image

    subtitle = " + ".join((tags or [])[:3]) or "美食挑战 + 沉浸咀嚼声"
    outputs: list[Path] = []
    with Image.open(source) as original:
        for index, style in enumerate(STYLES, 1):
            cover = _draw_cover(original, title, subtitle, (1280, 720), style, seed=index * 97)
            path = output_folder / f"cover_{index}_{style['name']}_16x9.jpg"
            cover.save(path, "JPEG", quality=93, optimize=True)
            outputs.append(path)
        default_cover = _draw_cover(original, title, subtitle, (900, 383), STYLES[0], seed=97)
        default_path = output_folder / "cover.jpg"
        default_cover.save(default_path, "JPEG", quality=93, optimize=True)
        outputs.insert(0, default_path)
    return outputs

