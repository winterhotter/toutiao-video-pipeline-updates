@echo off
title Build Toutiao Video Pipeline EXE
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Run install_windows.bat first.
  pause
  exit /b 1
)
call .venv\Scripts\python.exe -m pip install pyinstaller
call .venv\Scripts\pyinstaller.exe --noconfirm --clean --onefile --windowed --name "ToutiaoVideoPipeline" --collect-all yt_dlp --collect-all PIL launcher.pyw
echo.
echo Build completed. The app is in the dist folder.
echo FFmpeg must still be installed on the target computer.
pause

